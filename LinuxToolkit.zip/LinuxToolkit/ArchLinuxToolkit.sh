#!/bin/bash

#rm /tmp/debiandist /tmp/redhatdist /tmp/archdist /tmp/gentoodist /tmp/susedist

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

show_menu(){
NORMAL=`echo "\033[m"`
MENU=`echo "\033[36m"` #Blue
NUMBER=`echo "\033[33m"` #yellow
FGRED=`echo "\033[41m"`
GREEN_TEXT=`echo '\033[0;32m'`
RED_TEXT=`echo "\033[31m"`
ENTER_LINE=`echo "\033[33m"`
echo -e "${MENU}*********************************************${NORMAL}"
echo -e "${MENU}**${NUMBER} 1)${MENU} ${GREEN_TEXT}System & Hardware information ${NORMAL}       ${MENU}**"
echo -e "${MENU}**${NUMBER} 2)${MENU} ${GREEN_TEXT}CPU utilisation % over 30 seconds ${NORMAL}   ${MENU}**"
echo -e "${MENU}**${NUMBER} 3)${MENU} ${GREEN_TEXT}Networking information ${NORMAL}		   ${MENU}**"
echo -e "${MENU}**${NUMBER} 4)${MENU} ${GREEN_TEXT}Package Management ${NORMAL}		   ${MENU}**"
echo -e "${MENU}*********************************************${NORMAL}"
echo -e "${ENTER_LINE}Please enter a menu option (1-4) or ${RED_TEXT}'x' ${NUMBER}to exit. ${NORMAL}"
echo
echo "You are using a 'Arch - Linux' type distribution!"
echo
read opt
}
function option_picked() {
	COLOR='\033[01;31m' # bold red
	RESET='\033[00;00m' # normal white
	MESSAGE=${@:-"${RESET}Error: No message passed"}
	echo -e "${COLOR}${MESSAGE}${RESET}"
}

clear
show_menu
while [ opt != '' ]
	do
	if [[ $opt = "" ]]; then 
			exit;
	else
		case $opt in

		1) clear;
			option_picked "Option 1 Picked";
			./SysMonArch.sh
			show_menu
			;;

		2) clear;
			option_picked "Option 2 Picked";
			file=/usr/bin/bc
			if [ -e "$file" ]; then
				echo
				echo -e '\033[0;31m'"BC application already installed, Ok to proceed!" $tecreset
				echo
			else 
				echo
				echo -e '\033[0;31m'"BC application is not installed on device, part of the script will not work without it!"
				echo "Would you like to install 'BC'?(y/n):" $tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					zypper install bc
				else
					echo 
				fi
			fi
			echo
			echo -e '\033[0;31m'"Please wait whilst averages are calculated..." $tecreset		
			./Average.sh
			show_menu
			;;

		3) clear;
			option_picked "Option 3 Picked";
			file=/usr/bin/netstat
			if [ -e "$file" ]; then
				echo
				echo -e '\033[0;31m'"Netstat application already installed, Ok to proceed!" $tecreset
				echo
			else 
				echo
				echo -e '\033[0;31m'"Netstat application is not installed on device, part of the script will not work without it!"
				echo "Would you like to install 'Netstat'?(y/n):" $tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					zypper install net-tools-deprecated
				else
					echo 
				fi
			fi
			./NetMonArch.sh
			show_menu
			;;
			
		4) clear;
			option_picked "Option 4 Picked";
			./PackageManagement.sh
			show_menu
			;;

		x)exit;
		;;

		\n)exit;
		;;

		*)clear;
		option_picked "Pick an option from the menu";
		show_menu;
		;;
	esac
fi
done
