                  ####################################################################################################
                  #                        LJCH_(Networking Information)NetMon.sh                                    #                                                                                                                                             #
                  ####################################################################################################
                  
                  
#! /bin/bash	
										
clear								#clear the screen 

unset tecreset os architecture kernelrelease internalip externalip nameserver loadaverage							#unsets any variables which may have been previously set 

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

while getopts iv name				#getopts is used by shell procedures to parse positional parameters/arguments | iv being 2 positional parameters and * covering all other results
do 
        case $name in				#case used instead of mutiple (if, else, fi) statements | $name being the variable used to carry positional parameters 
          i)iopt=1;;				#used with ./Monitor -i (installing Monitor.sh line 21 -29) | =1 showing it as a successful result
          v)vopt=1;;				#used with ./Monitor.sh -v (showing version results)
          *)echo "Invalid arg";;	#all other results show as invalid argument (* Expands to all the words of all the positional parameters)
        esac
done

#cdr=$(find / -name "SystemNetworkMonitor" > /tmp/currentdirectory)
#$cdr
#find / -name "SystemNetworkMonitor" > /tmp/currentdirectory					#Locate script folder and output result to tmp file
#curdir=$(cat /tmp/currentdirectory | sed '1!d')								#Set script location as curdir variable
#cd $curdir																		#Navigate to above locatio

if [[ ! -z $iopt ]]					#$iopt takes first positional parameter and sets it as a variable | [[ returns a status of 1 or 0 dependant on conditions | ! inverts the condition | -z means true if length of string is 0)
then
{
wd=$(pwd)																	 																			#runs pwd (print working directory) command in subshell and returns as value 
basename "$(test -L "$0" && readlink "$0" || echo "$0")" > /tmp/scriptname   																			#setting Monitor.sh to scriptname in temp directory | test -L checks file exists and is a symbolic link | readlink prints resolved symbolic links | then echos result
scriptname=$(echo -e -n $wd/ && cat /tmp/scriptname)																									#echo -e -n enables interpretation of backslash escapes and does not output the trailing newline of working directory and displays Monitor.sh to terminal
su -c "cp $scriptname /usr/bin/monitor" root && echo "Congratulations! Script Installed, now run monitor Command" || echo "Installation failed" 		#su -c means executed command will have no controlling terminal | copy script name to directory of executables and name 'monitor' and echo result depending on if successful
}
fi

if [[ ! -z $vopt ]]																											#[[ returns a status of 1 or 0 dependant on conditions | ! inverts the condition | -z means true if length of string is 0 | $vopt sets variable as ./Monitor.sh -v (checking if command has been run and continues depending on result)
then
{
echo -e "LJCH - System & Network Monitor ,\nWritten by Laurence Harding"					#display quoted text to terminal | -e feature enable interpretation of backslash escapes
}
fi

if [[ $# -eq 0 ]]														# $# counts positional parameters | -eq 0 checking if positional parameters is equal to 0
then
{

#cdr=$(find / -name "SystemNetworkMonitor" > /tmp/currentdirectory)
#curdir=$(cat /tmp/currentdirectory | sed '1!d')
#file="/tmp/currentdirectory"
#if [ -f "$file" ]
#then
#	$cdr
#	cd $curdir
#else
#	echo "Application location not found!!!"
#fi

# Offer of installing script for 'monitor' command
monitor=$(./Monitor.sh -i)												#stores monitor variable as ./Monitor.sh -i command
file="/usr/bin/monitor"													#sets file as /usr/bin/monitor
if [ -f "$file" ]														#if file matches $file variable previously set
then											
	echo -e '\033[0;31m'"Monitor command already exists!" $tecreset						#output to terminal with red change of colour (\033[0;31m) and echo message, then switch colour back to default ($tecreset)
else
	echo -e '\033[0;31m'"Would you like to install 'monitor' command?(y/n):" $tecreset			#output option y/n
	read user_input																		#read input 
	if [ ${user_input} = y ]															#if user input = y
	then
		$monitor
	else
		echo															#any other user input outputs a blank line
	fi
fi

# Define Variable tecreset
#tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

# Offer of installing script for 'monitor' command
#monitor=$(./Monitor.sh -i)												#stores monitor variable as ./Monitor.sh -i command
#file="/usr/bin/monitor"													#sets file as /usr/bin/monitor
#if [ -f "$file" ]														#if file matches $file variable previously set
#then											
#	echo -e '\033[0;31m'"Monitor command already exists!" $tecreset		#output to terminal with red change of colour (\033[0;31m) and echo message, then switch colour back to default ($tecreset)
#else
#	cd /root/Desktop/													#Navigate to script location
#	echo "Would you like to install 'monitor' command?(y/n): "			#output option y/n
#	read user_input														#read input 
#	if [ ${user_input} = y ]											#if user input = y
#	then
#		echo -e '\033[0;31m'"Packet Statistics: $tecreset " "$monitor"	#output to terminal with red change of colour, then switch colour back to default | followed by monitor variable
#	else
#		echo															#any other user input outputs a blank line
#	fi
#fi


# Check for sensors executable
sensorsinstall=$(sudo yum install lm-sensors.x86_64)
file=/usr/bin/sensors
if [ -e "$file" ]; then
    echo -e '\033[0;31m'"Sensors application already installed, Ok to proceed!" $tecreset
else
    echo
    echo -e '\033[0;31m'"Sensors application is not installed on device, part of the script will not work without it!"
    echo
    echo "Would you like to install 'Sensors'?(y/n):" $tecreset
    read user_input
    if [ ${user_input} = y ]
    then
#	echo -e "$sensorsinstall"
	yum install lm-sensors.x86_64
	echo
    else
        echo 
    fi
fi 



# Check for finger executable
fingerinstall=$(sudo yum install finger)
file=/usr/bin/finger
if [ -e "$file" ]; then
    echo -e '\033[0;31m'"Finger application already installed, Ok to proceed!" $tecreset   
else
    echo -e '\033[0;31m'"Finger application is not installed on device, part of the script will not work without it!"
    echo "Would you like to install 'Finger'?(y/n):" $tecreset
    read user_input
    if [ ${user_input} = y ]
    then
#	echo -e "y | $fingerinstall"
	yum install finger
	echo
    else
	 echo 
    fi 
fi 

# Check for dmidecode executable
dmiinstall=$(sudo yum install dmidecode)
file="/usr/sbin/dmidecode"
if [ -f "$file" ]
then
	echo -e '\033[0;31m'"Dmidecode application already installed, Ok to proceed!" $tecreset
else
	echo "Dmidecode application is not installed on device, part of the script will not work without it!"
	echo "Would you like to install 'Dmidecode'?(y/n): "
	read user_input
	if [ ${user_input} = y ]
	then
#	    echo -e "$dmiinstall"
	    yum install dmidecode
	    echo
	else
	    echo
	fi
fi

# Check for ufw executable
ufwinstall=$(sudo yum install ufw)
file="/usr/sbin/ufw"
if [ -f "$file" ]
then
	echo -e '\033[0;31m'"UFW application already installed, Ok to proceed!" $tecreset
	echo
else
	echo "UFW application is not installed on device, part of the script will not work without it!"
	echo "Would you like to install 'UFW'?(y/n): "
	read user_input
	if [ ${user_input} = y ]
	then
#	    echo -e "$ufwinstall"
	    yum install dmidecode
	    echo
	else
	    echo
	fi
fi

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

externalip=$(curl -s ipecho.net/plain;echo)								#External IP -explained further down script


# Location of user
#whois=$(whois)
#externalip1=$(cat /tmp/externalipoutput)	
#externalip=$(curl -s ipecho.net/plain;echo > /tmp/externalipoutput)														
#echo -e '\033[0;31m'"Location of User:" $tecreset $externalip  
#echo 'whois' $externalip1 | sed '10!d' | awk '{print $2}' 				#Piping whois command external IP variable
#echo -e '\033[0;31m'"Location of User:" whois $externalip
#echo -e "$whois $externalip"											#Location of user | whois command - client for the whois directory service

#echo

# Day, date, time, year
#ddty=$(TZ="Africa/Casablanca" date)								    #
#echo -e '\033[0;31m'"Day, date, time, year:" $tecreset $ddty

#echo

#echo
# Check if connected to Internet or not
ping -c 1 google.com &> /dev/null && echo -e '\033[0;31m'"Internet: $tecreset Connected" || echo -e '\033[0;31m'"Internet: $tecreset Disconnected"		#'\033[0;31m' is the colour green | ping result outputted to /dev/null using &> meaning Syntax to redirection of both standard error and output to a file |  || function displays 2nd result if first fails!

#echo

# Network Interface Cards
nic=$(cat /proc/net/dev | sed '1 d' | awk '{print $1}')								#cat -output to terminal (/proc/net/dev) | sed removes first line | awk prints only first word of remaining lines
echo -e '\033[0;31m'"Available Network Interfaces:" $tecreset $nic					#all network interfaces seperated by :

#echo

# IPv4 Address
#ipv4add=$(ifconfig | sed '2!d' | awk '{print $2}')									#IPv4 Addess | keeps only line 2 | keeps only 2nd word
ipv4add=$(hostname -I)																#hostname command with argument for IP address
echo -e '\033[0;31m'"IPv4:" $tecreset $ipv4add 

#echo

# IPv6 Address
ipv6add=$(ifconfig | sed '3!d' | awk '{print $2 $3}')								#IPv6 Addess | keeps only line 3 | keeps only 2nd + 3rd word
echo -e '\033[0;31m'"IPv6:" $tecreset $ipv6add 					

# Check External IP 
externalip=$(curl -s ipecho.net/plain;echo)											#curl -s means silent mode (run in background) | ipecho.net external IP echo service | echo plain text result and save to $externalip variable
echo -e '\033[0;31m'"External IP: $tecreset "$externalip							#ifconfig -network interface info
#echo

# UFW Status
ufwstatus=$(ufw status verbose)											#ufw -program for managing a netfilter firewall | arg. in detail
echo -e '\033[0;31m'"UFW Status:" 
echo $tecreset"$ufwstatus"     											#UFW Status

echo

# Check Network Adapter Details
nadapter=$(lspci -nnk | grep net -A2)											#lspci - list all PCI devices arg. Show PCI vendor and device codes as both numbers and names arg. show kernel drivers | grep net results
echo -e '\033[0;31m'"Network Adapter Details:" 
echo $tecreset"$nadapter"

echo

# ARP Table
arptable=$(arp -a)																#arp -manipulate the system ARP cache arg. Use alternate BSD style output format 
echo -e '\033[0;31m'"ARP Table:" 
echo $tecreset"$arptable"     													#ARP Table

echo

# Kernel IP Routing Table
routetable=$(netstat -r)														#netstat with arg. Display the kernel routing tables
echo -e '\033[0;31m'"IP Routing Table:" 										#Kernel IP routing table
echo $tecreset"$routetable" 

echo

# Check DNS
nameservers=$(cat /etc/resolv.conf | sed '1 d' | awk '{print $2}')		#/etc/resolv.conf contains nameserver (dns) | sed '1 d' removes first 2 lines of input file | awk '{print $2}' prints the second word of remaining lines (127.0.1.1 & parkinsurance.local)
echo -e '\033[0;31m'"Name Servers:" $tecreset $nameservers 

echo

# NSLOOKUP Localhost
nslookup=$(nslookup localhost)											#nslookup - query Internet name servers interactively on internal IP (localhost)
echo -e '\033[0;31m'"Nslookup Localhost:" 
echo $tecreset"$nslookup"     											#NSLOOKUP Localhost

echo

# LSOF Listening & Established Connections
lsofle=$(lsof -i)														#lsof -list files arg. selects the listing of files any of whose Internet address matches the address specified in i
echo -e '\033[0;31m'"All Listening & Established Connections:" 
echo $tecreset"$lsofle"     											#Listening & Established Connections

echo

# Netstat (TCP)
netstatcon=$(netstat -ant)												#Netstats arg. all arg. numeric arg. tcp
echo -e '\033[0;31m'"Netstat TCP Connections:" 
echo $tecreset"$netstatcon"     										#Active Internet TCP connections (servers and established)

echo

# Netstat (UDP)
netstatudp=$(netstat -au)												#Netstat arg. all arg. udp
echo -e '\033[0;31m'"Netstat UDP Connections:" 
echo $tecreset"$netstatudp"     										#Netstat UDP Connections 

echo

# Find Listening SSH Connections
listenssh=$(netstat -ap | grep ssh)										#Netstat arg. all arg. program | grep filters ssh results
echo -e '\033[0;31m'"Listening SSH Connections:" 
echo $tecreset"$listenssh"     											#Find Listening SSH Connections

echo

# Check Connection Speed to Google (http)
connectspeed1=$(curl -s -w 'Testing Website Response Time for :%{url_effective}\n\nLookup Time:\t\t%{time_namelookup}\nConnect Time:\t\t%{time_connect}\nPre-transfer Time:\t%{time_pretransfer}\nStart-transfer Time:\t%{time_starttransfer}\n\nTotal Time:\t\t%{time_total}\n' -o /dev/null http://www.google.com)
echo -e '\033[0;31m'"Connection Speed to Google (http):" 
echo $tecreset"$connectspeed1"											#curl - transfer a URL arg. silent arg. write out following results of http connection to google

echo

# Check Connection Speed to Google (https)
connectspeed2=$(curl -s -w 'Testing Website Response Time for :%{url_effective}\n\nLookup Time:\t\t%{time_namelookup}\nConnect Time:\t\t%{time_connect}\nAppCon Time:\t\t%{time_appconnect}\nRedirect Time:\t\t%{time_redirect}\nPre-transfer Time:\t%{time_pretransfer}\nStart-transfer Time:\t%{time_starttransfer}\n\nTotal Time:\t\t%{time_total}\n' -o /dev/null https://www.google.com)
echo -e '\033[0;31m'"Connection Speed to Google (https):" 
echo $tecreset"$connectspeed2"											#curl - transfer a URL arg. silent arg. write out following results of https connection to google

echo

echo -e '\033[0;31m'"Would you like to whois external IP? (y/n): $tecreset "
read user_input
if [ ${user_input} = y ]
then
	echo
	echo -e '\033[0;31m'"Whois On External IP: $tecreset "
	echo -e '\033[0;31m'"Whois On External IP: $tecreset "| whois $externalip		#Piping whois command external IP variable
else
	echo
fi

# Packet Statistics
packetstats=$(netstat -s)															#Netstat statistics results
echo -e '\033[0;31m'"Would you like to see packet statistics? (y/n): $tecreset "
read user_input
if [ ${user_input} = y ]
then
	echo
	echo -e '\033[0;31m'"Packet Statistics: $tecreset "
	echo "$packetstats"
else
	echo
fi

echo

# Tracreroute on External IP
traceroute=$(traceroute $externalip)												#traceroute - print the route packets trace to external IP 
echo -e '\033[0;31m'"Would you like to run traceroute on external IP? (y/n): $tecreset"
read user_input
if [ ${user_input} = y ]
then
	echo
	echo -e '\033[0;31m'"Traceroute on External IP: $tecreset "
	echo "$traceroute"
else
	echo
fi

echo

# Tracreroute on google.com
traceroutegoogle=$(traceroute google.com)											#traceroute - print the route packets trace to google.com
echo -e '\033[0;31m'"Would you like to run traceroute on google.com? (y/n): $tecreset "
read user_input
if [ ${user_input} = y ]
then
	echo
	echo -e '\033[0;31m'"Traceroute on google.com: $tecreset "
	echo "$traceroutegoogle"
else
	echo
fi

echo

# Check Internal IP
#internalip=$(hostname -I)
#echo -e '\033[0;31m'"Internal IP:" $tecreset $internalip				#commented out due to previously provided

#echo

# Check External IP & Whois Result
#externalip=$(curl -s ipecho.net/plain;echo)							#curl -s means silent mode (run in background) | ipecho.net external IP echo service | echo plain text result and save to $externalip variable
#echo -e '\033[0;31m'"External IP: $tecreset "$externalip				#commented out due to previously provided
#echo

# Unset Variables
unset tecreset internalip externalip nameserver		#removes all previously set variables with unset command


}
fi																								#ends if statement
shift $(($OPTIND -1))																			#needed to end getopts command | $(($OPTIND -1)) removes all the options that have been parsed by getopts from the parameters list

