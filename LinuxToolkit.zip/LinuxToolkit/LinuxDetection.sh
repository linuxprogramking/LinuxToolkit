#!/bin/bash

#rm /tmp/debiandist /tmp/redhatdist /tmp/archdist /tmp/gentoodist /tmp/susedist

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

#uname -v | awk '{print $3}' > /tmp/debiandist	
cat /etc/os-release  > /tmp/debiandist
cat /proc/version > /tmp/redhatdist
cat /etc/os-release  > /tmp/archdist
cat /proc/version > /tmp/gentoodist
cat /etc/os-release > /tmp/mainslackdist
command -v dmseg | head -1 > /tmp/susedist
#cat /etc/os-release > /tmp/fedoradist
	
		
#Debian distribution check
isInFile=$(cat /tmp/debiandist | grep -c "ID_LIKE=debian")
if [ $isInFile -eq 1 ];												
then
	echo
	./DebianLinuxToolkit.sh
else
	echo -e '\033[0;31m'"Debian distribution NOT detected"$tecreset
fi

#Redhat distribution check
isInFile=$(cat /tmp/redhatdist | grep -c "(Red")
if [ $isInFile -eq 1 ];												
then
	echo
	./RedhatLinuxToolkit.sh
else
	echo -e '\033[0;31m'"Redhat distribution NOT detected"$tecreset
fi

#Arch distribution check
#isInFile=$(cat /tmp/archdist | grep -c "ID=blackarch")					#line of VM working version
#isInFile=$(cat /tmp/archdist | grep -c "ID=arch")					#line for general arch distribution
isInFile=$(cat /tmp/archdist | grep -c "ID=arch")
if [ $isInFile -eq 1 ];												
then
	echo
	./ArchLinuxToolkit.sh
else
	isInFile=$(cat /tmp/archdist | grep -c "ID=blackarch")
	if [ $isInFile -eq 1 ];												
	then
		echo
		./ArchLinuxToolkit.sh
	else
		echo -e '\033[0;31m'"Arch distribution NOT detected"$tecreset
	fi
fi

#Enoch distribution check
isInFile=$(cat /tmp/gentoodist | grep -c "(Gentoo")
if [ $isInFile -eq 1 ];												
then
	echo
	./EnochLinuxToolkit.sh
else
	echo -e '\033[0;31m'"Enoch distribution NOT detected"$tecreset
fi

#Slackware distribution check
isInFile=$(cat /tmp/gentoodist | grep -c "SUSE")
if [ $isInFile -eq 1 ];												
then
	echo
	./SlackwareLinuxToolkit.sh
else
	isInFile=$(cat /tmp/mainslackdist | grep -c "Name=Slackware")
	if [ $isInFile -eq 1 ];												
	then
		echo
		./SlackwareLinuxToolkit.sh
	else
		echo -e '\033[0;31m'"Slackware distribution NOT detected"$tecreset
	fi
fi

echo	
							
rm /tmp/debiandist /tmp/redhatdist /tmp/archdist /tmp/gentoodist /tmp/susedist











