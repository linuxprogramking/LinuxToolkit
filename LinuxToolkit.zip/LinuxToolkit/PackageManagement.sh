#!/bin/bash

#rm /tmp/debiandist /tmp/redhatdist /tmp/archdist /tmp/gentoodist /tmp/susedist

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

# default display on current host
#DISPLAY=:0.0

#Check for gedit executable  
#geditinstall1=$(sudo apt || apt install gedit)
#geditinstall2=$(sudo rpm -i gedit)
#geditinstall3=$(zypper install gedit)
#geditinstall4=$(sudo pacman -S gedit)
#file="/usr/bin/gedit"
#if [ -f "$file" ]
#then
#	echo -e '\033[0;31m'"Gedit application already installed, Ok to proceed!" $tecreset
#	echo
#else
#	echo "Gedit application is not installed on device, part of the script will not work without it!"
#	echo "Would you like to install 'Gedit'?(y/n): "
#	read user_input
#	if [ ${user_input} = y ]
#	then
#		echo -e $geditinstall1
#		echo -e $geditinstall2
#		echo -e "$geditinstall3"
#		echo -e $geditinstall4
#	else
#		echo
#	fi
#fi

#uname -v | awk '{print $3}' > /tmp/debiandist	
cat /etc/os-release  > /tmp/debiandist
cat /proc/version > /tmp/redhatdist
cat /etc/os-release  > /tmp/archdist
cat /proc/version > /tmp/gentoodist
command -v dmseg | head -1 > /tmp/susedist
#cat /etc/os-release > /tmp/fedoradist
		
#Debian distribution check
isInFile=$(cat /tmp/debiandist | grep -c "ID_LIKE=debian")
if [ $isInFile -eq 1 ];												
then
	dpkg --get-selections > /tmp/programlist
	echo
	echo "You are using a Debian Linux distribution"
	echo
	echo -e '\033[0;31m'"Would you like to see a list of all installled programs?(y/n):"$tecreset
	read user_input
	if [ ${user_input} = y ]
	then
		showprogram=$(gedit /tmp/programlist)
		echo "$showprogram"
	else
		echo
	fi
		echo
		echo -e '\033[0;31m'"Would you like to update/upgrade security/packages?(y/n):"$tecreset
		read user_input
		if [ ${user_input} = y ]
		then
			aptupdateupgrade=$(apt update && apt upgrade)
			echo "yes | $aptupdateupgrade"
			echo
		else 
			echo
		fi
			echo -e '\033[0;31m'"Would you like to search for a package(y/n):"$tecreset
			read user_input
			if [ ${user_input} = y ]
			then
				echo
				echo -e '\033[0;31m'"Enter package name:"$tecreset
				read packagename
				aptcachesearch=$(apt-cache search $packagename)
				echo "$aptcachesearch"
				echo 
			else
				echo
			fi
				echo -e '\033[0;31m'"Would you like to install a package(y/n):"$tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					echo
					echo -e '\033[0;31m'"Enter package name:"$tecreset
					read packagename1
					aptinstall=$(apt install $packagename1)
					echo "$aptinstall" 
					echo
				else
					echo
				fi
					echo -e '\033[0;31m'"Would you like to remove/purge a package(y/n):"$tecreset
					read user_input
					if [ ${user_input} = y ]
					then
						echo
						echo -e '\033[0;31m'"Enter package name:"$tecreset
						read packagename2
						aptpurge=$(yes | apt purge $packagename2)
						echo "$aptpurge" 
						echo
					else
						echo
					fi	
else
	echo -e '\033[0;31m'"Debian distribution NOT detected"$tecreset
fi

#Redhat distribution check
isInFile=$(cat /tmp/redhatdist | grep -c "(Red")
if [ $isInFile -eq 1 ];												
then
	rpm -qa > /tmp/programlist
	echo
	echo "You are using a Redhat Linux distribution"
	echo
	echo -e '\033[0;31m'"Would you like to see a list of all installled programs?(y/n):"$tecreset
	read user_input
	if [ ${user_input} = y ]
	then
		echo
		showprogram=$(cat /tmp/programlist)
		echo "$showprogram"
		echo
	else
		echo
	fi
		echo -e '\033[0;31m'"Would you like to uprgade/update?(y/n):"$tecreset
		read user_input
		if [ ${user_input} = y ]
		then
			echo
			yumupgradeupdate=$(yes |yum update && yes | yum upgrade)
			echo "$yumupgradeupdate"
			echo 
		else 
			echo
		fi
			echo -e '\033[0;31m'"Would you like to search for a package(y/n):"$tecreset
			read user_input
			if [ ${user_input} = y ]
			then
				echo
				echo -e '\033[0;31m'"Enter package name:"$tecreset
				read packagename4
				yumsearch=$(yum search $packagename4)
				echo "$yumsearch"
				echo 
			else
				echo
			fi
				echo -e '\033[0;31m'"Would you like to install a package(y/n):"$tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					echo
					echo -e '\033[0;31m'"Enter package name:"$tecreset
					read packagename5
					yuminstall=$(yum install $packagename5)
					echo "$yuminstall" 
					echo
				else
					echo
				fi
					echo -e '\033[0;31m'"Would you like to remove a package(y/n):"$tecreset
					read user_input
					if [ ${user_input} = y ]
					then
						echo
						echo -e '\033[0;31m'"Enter package name:"$tecreset
						echo
						read packagename6
						yumremove=$(yum remove $packagename6)
						echo "$yumremove" 
						echo
					else
						echo
					fi
else
	echo -e '\033[0;31m'"Redhat distribution NOT detected"$tecreset
fi

#Arch distribution check
isInFile=$(cat /tmp/archdist | grep -c "ID=blackarch")			#line of VM working version
#isInFile=$(cat /tmp/archdist | grep -c "ID=arch")				#line for general arch distribution
if [ $isInFile -eq 1 ];												
then
	pacman -Q > /tmp/programlist
	echo
	echo "You are using a Arch Linux distribution" 
	echo
	echo -e '\033[0;31m'"Would you like to see a list of all installled programs?(y/n):"$tecreset
	read user_input
	if [ ${user_input} = y ]
	then
		showprogram=$(gedit /tmp/programlist)
		echo "$showprogram"
		echo
	else
		echo
	fi
		echo -e '\033[0;31m'"Would you like to uprgade/update a package?(y/n):"$tecreset
		read user_input
		if [ ${user_input} = y ]
		then
			echo
			echo -e '\033[0;31m'"Enter package name:"$tecreset
			read packagename7
			pacmanupgrade=$(pacman -Syu $packagename7)
			echo "$pacmanupgrade"
			echo 
		else 
			echo
		fi
			echo -e '\033[0;31m'"Would you like to search for a package(y/n):"$tecreset
			read user_input
			if [ ${user_input} = y ]
			then
				echo
				echo -e '\033[0;31m'"Enter package name:"$tecreset
				read packagename8
				pacmansearch=$(pacman -Ss $packagename8)
				echo "$pacmansearch"
				echo 
			else
				echo
			fi
				echo -e '\033[0;31m'"Would you like to install a package(y/n):"$tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					echo
					echo -e '\033[0;31m'"Enter package name:"$tecreset
					read packagename9
					pacmaninstall=$(pacman -S $packagename9)
					echo "$pacmaninstall" 
					echo
				else
					echo
				fi
					echo -e '\033[0;31m'"Would you like to remove a package(y/n):"$tecreset
					read user_input
					if [ ${user_input} = y ]
					then
						echo
						echo -e '\033[0;31m'"Enter package name:"$tecreset
						read packagename10
						pacmanremove=$(pacman -R $packagename10)
						echo "$pacmanremove" 
						echo
					else
						echo
					fi
else
	echo -e '\033[0;31m'"Arch distribution NOT detected"$tecreset
fi

#Enoch distribution check
isInFile=$(cat /tmp/gentoodist | grep -c "(Gentoo")
if [ $isInFile -eq 1 ];												
then
    equery list "*" > /tmp/programlist
	echo
	echo "You are using a Enoch Linux distribution"
	echo
	echo -e '\033[0;31m'"Would you like to see a list of all installled programs?(y/n):"$tecreset
	read user_input
	if [ ${user_input} = y ]
	then
		showprogram=$(cat /tmp/programlist)
		echo "$showprogram"
		echo
	else
		echo
	fi
		echo -e '\033[0;31m'"Would you like to update packages?(y/n):"$tecreset
		read user_input
		if [ ${user_input} = y ]
		then
			echo
			pmupdate=$(emerge -uDU --keep-going --with-bdeps=y @world)
			echo "$pmupdate"
			echo 
		else 
			echo
		fi
			echo -e '\033[0;31m'"Would you like to search for a package(y/n):"$tecreset
			read user_input
			if [ ${user_input} = y ]
			then
				echo
				echo -e '\033[0;31m'"Enter package name:"$tecreset
				read packagename12
				emergesearch=$(emerge --search query $packagename12)
				echo "$emergesearch"
				echo 
			else
				echo
			fi
				echo -e '\033[0;31m'"Would you like to install a package(y/n):"$tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					echo
					echo -e '\033[0;31m'"Enter package name:"$tecreset
					read packagename13
					emergeinstall=$(emerge $packagename13)
					echo "$emergeinstall" 
					echo
				else
					echo
				fi
					echo -e '\033[0;31m'"Would you like to remove a package(y/n):"$tecreset
					read user_input
					if [ ${user_input} = y ]
					then
						echo
						echo -e '\033[0;31m'"Enter package name:"$tecreset
						read packagename14
						unemergeremove=$(emerge --unmerge $packagename14)
						echo "$unemergeremove" 
						echo
					else
						echo
					fi
else
	echo -e '\033[0;31m'"Enoch distribution NOT detected"$tecreset
fi

#Slackware distribution check
isInFile=$(cat /tmp/gentoodist | grep -c "SUSE")
if [ $isInFile -eq 1 ];												
then
	zypper se > /tmp/programlist
	echo
	echo "You are using a Slackware Linux distribution"
	echo
	echo -e '\033[0;31m'"Would you like to see a list of all installed programs?(y/n):"$tecreset
	read user_input
	if [ ${user_input} = y ]
	then
		#Kate application check
		file=/usr/bin/kate
		if [ -e "$file" ]; then
			echo
			echo -e '\033[0;31m'"Kate application already installed, Ok to proceed!" $tecreset
			echo
		else 
			echo
			echo -e '\033[0;31m'"Kate application is not installed on device, part of the script will not work without it!"
			echo "Would you like to install 'kate'?(y/n):" $tecreset
			read user_input
			if [ ${user_input} = y ]
			then
				zypper install kate
			else
				echo 
			fi
		fi
		showprogram=$(kate /tmp/programlist)
		echo "$showprogram"
	else
		echo
	fi
		echo
		echo -e '\033[0;31m'"Would you like to uprgade/update packages?(y/n):"$tecreset
		read user_input
		if [ ${user_input} = y ]
		then
			echo
			zypperupdate=$(zypper update)
			echo "$zypperupdate"
			echo 
		else 
			echo
		fi
			echo -e '\033[0;31m'"Would you like to search for a package(y/n):"$tecreset
			read user_input
			if [ ${user_input} = y ]
			then
				echo
				echo -e '\033[0;31m'"Enter package name:"$tecreset
				read packagename15
				zyppersearch=$(zypper se $packagename15)
				echo "$zyppersearch"
				echo 
			else
				echo
			fi
				echo -e '\033[0;31m'"Would you like to install a package(y/n):"$tecreset
				read user_input
				if [ ${user_input} = y ]
				then
					echo
					echo -e '\033[0;31m'"Enter package name:"$tecreset
					read packagename16
					zypperinstall=$(sudo zypper install $packagename16)
					echo "$zypperinstall" 
					echo
				else
					echo
				fi
					echo -e '\033[0;31m'"Would you like to remove a package(y/n):"$tecreset
					read user_input
					if [ ${user_input} = y ]
					then
						echo
						echo -e '\033[0;31m'"Enter package name:"$tecreset
						read packagename17
						zypperremove=$(zypper remove $packagename17)
						echo "$zypperremove" 
						echo
					else
						echo
					fi
else
	echo -e '\033[0;31m'"Slackware distribution NOT detected"$tecreset
fi

#Fedora distribution check
#isInFile=$(cat /tmp/fedoradist | grep -c "*fedora")
#if [ $isInFile -eq 1 ];												
#then
#	rpm -qa > /tmp/programlist
#	echo
#	echo "You are using a Fedora (Redhat) Linux distribution"
#	echo
#	echo -e '\033[0;31m'"Would you like to see a list of all installled programs?(y/n):"$tecreset
#	read user_input
#	if [ ${user_input} = y ]
#	then
#		showprogram=$(gedit /tmp/programlist)
#		echo "$showprogram"
#	else
#		echo
#	fi
#		echo -e '\033[0;31m'"Would you like to uprgade a package?(y/n):"$tecreset
#		read user_input
#		if [ ${user_input} = y ]
#		then
#			echo
#			echo -e '\033[0;31m'"Enter package name:"$tecreset
#			read packagename18
#			rpmupgrade=$(rpm -Uvh $packagename18)
#			echo "$rpmupgrade"
#			echo 
#		else 
#			echo
#		fi
#			echo -e '\033[0;31m'"Would you like to search for a package(y/n):"$tecreset
#			read user_input
#			if [ ${user_input} = y ]
#			then
#				echo
#				echo -e '\033[0;31m'"Enter package name:"$tecreset
#				read packagename19
#				rpmsearch=$(rpm -q $packagename19)
#				echo "$rpmsearch"
#				echo 
#			else
#				echo
#			fi
#				echo -e '\033[0;31m'"Would you like to install a package(y/n):"$tecreset
#				read user_input
#				if [ ${user_input} = y ]
#				then
#					echo
#					echo -e '\033[0;31m'"Enter package name:"$tecreset
#					read packagename20
#					rpminstall=$(rpm -ivh $packagename20)
#					echo "$rpminstall" 
#					echo
#				else
#					echo
#				fi
#					echo -e '\033[0;31m'"Would you like to remove a package(y/n):"$tecreset
#					read user_input
#					if [ ${user_input} = y ]
#					then
#						echo
#						echo -e '\033[0;31m'"Enter package name:"$tecreset
#						read packagename21
#						rpmremove=$(rpm -evv $packagename21)
#						echo "$rpmremove" 
#						echo
#					else
#						echo
#					fi
#else
#	echo -e '\033[0;31m'"Fedora (Redhat) distribution NOT detected"$tecreset
#fi


#Check for gedit executable  
#geditinstall1=$(sudo apt install gedit)
#geditinstall2=$(sudo rpm -i gedit)
#geditinstall3=$(sudo zypper install gedit)
#geditinstall4=$(sudo pacman -S gedit)
#file="/usr/bin/gedit"
#if [ -f "$file" ]
#then
#	echo -e '\033[0;31m'"Gedit application already installed, Ok to proceed!" $tecreset#
#	echo
#else
#	echo "Gedit application is not installed on device, part of the script will not work without it!"
#	echo "Would you like to install 'Gedit'?(y/n): "
#	read user_input
#	if [ ${user_input} = y ]
#	then
#		echo -e $geditinstall1
#		echo -e $geditinstall2
#		echo -e $geditinstall3
#		echo -e $geditinstall4
#	else
#		echo
#	fi
#fi

echo
echo
							
rm /tmp/debiandist /tmp/redhatdist /tmp/archdist /tmp/gentoodist /tmp/susedist











