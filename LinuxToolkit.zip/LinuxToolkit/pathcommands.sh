#!/bin/bash

#How many commands: a simple script to count how many executable
#commands are in your current PATH

IFS=":"													#Splitting fields
count=0 ; nonex=0
for directory in $PATH ; do
	if [ -d "$directory" ] ; then						#sets $directory variable as $PATH
	for command in "$directory"/* ; do
		if [ -x "$command" ] ; then						#$count variable holds the number of executables 
			count="$(( $count + 1 ))"
		else
			nonex="$(( $nonex + 1 ))"					#$nonex variable holds the number of entries that were not exectuable
		fi
	done
	fi
done

echo "$count commands, and $nonex entries that weren't executable"      #outputting result

exit 0
