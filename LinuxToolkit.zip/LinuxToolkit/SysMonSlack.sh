                  ####################################################################################################
                  #                          LJCH_(System & Hardware Information)SysMon.sh                           #                                                                                                                                             #
                  ####################################################################################################
                  
                  
#! /bin/bash	
										
clear								#clear the screen 

unset tecreset os architecture kernelrelease internalip externalip nameserver loadaverage							#unsets any variables which may have been previously set 

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

while getopts iv name				#getopts is used by shell procedures to parse positional parameters/arguments | iv being 2 positional parameters and * covering all other results
do 
        case $name in				#case used instead of mutiple (if, else, fi) statements | $name being the variable used to carry positional parameters 
          i)iopt=1;;				#used with ./Monitor -i (installing Monitor.sh line 21 -29) | =1 showing it as a successful result
          v)vopt=1;;				#used with ./Monitor.sh -v (showing version results)
          *)echo "Invalid arg";;	#all other results show as invalid argument (* Expands to all the words of all the positional parameters)
        esac
done

#cdr=$(find / -name "SystemNetworkMonitor" > /tmp/currentdirectory)
#$cdr
#find / -name "SystemNetworkMonitor" > /tmp/currentdirectory					#Locate script folder and output result to tmp file
#curdir=$(cat /tmp/currentdirectory | sed '1!d')								#Set script location as curdir variable
#cd $curdir																		#Navigate to above locatio

if [[ ! -z $iopt ]]					#$iopt takes first positional parameter and sets it as a variable | [[ returns a status of 1 or 0 dependant on conditions | ! inverts the condition | -z means true if length of string is 0)
then
{
wd=$(pwd)																	 																			#runs pwd (print working directory) command in subshell and returns as value 
basename "$(test -L "$0" && readlink "$0" || echo "$0")" > /tmp/scriptname   																			#setting Monitor.sh to scriptname in temp directory | test -L checks file exists and is a symbolic link | readlink prints resolved symbolic links | then echos result
scriptname=$(echo -e -n $wd/ && cat /tmp/scriptname)																									#echo -e -n enables interpretation of backslash escapes and does not output the trailing newline of working directory and displays Monitor.sh to terminal
su -c "cp $scriptname /usr/bin/monitor" root && echo "Congratulations! Script Installed, now run monitor Command" || echo "Installation failed" 		#su -c means executed command will have no controlling terminal | copy script name to directory of executables and name 'monitor' and echo result depending on if successful
}
fi

if [[ ! -z $vopt ]]																											#[[ returns a status of 1 or 0 dependant on conditions | ! inverts the condition | -z means true if length of string is 0 | $vopt sets variable as ./Monitor.sh -v (checking if command has been run and continues depending on result)
then
{
echo -e "LJCH - System & Network Monitor ,\nWritten by Laurence Harding"					#display quoted text to terminal | -e feature enable interpretation of backslash escapes
}
fi

if [[ $# -eq 0 ]]														# $# counts positional parameters | -eq 0 checking if positional parameters is equal to 0
then
{



# Check for finger executable
fingerinstall=$(zypper install finger)
file=/usr/share/doc/finger/changelog.Debian.gz
if [ -e "$file" ]; then
	echo -e '\033[0;31m'"Finger application is not installed on device, part of the script will not work without it!"
	echo "Would you like to install 'Finger'?(y/n):" $tecreset
	read user_input
	if [ ${user_input} = y ]
	then
		echo -e "$fingerinstall"
	else
		echo 
	fi
else 
    echo -e '\033[0;31m'"Finger application already installed, Ok to proceed!" $tecreset
fi 

# Check for dmidecode executable
dmiinstall=$(zypper install dmidecode)
file="/usr/sbin/dmidecode"
if [ -f "$file" ]
then
	echo -e '\033[0;31m'"Dmidecode application already installed, Ok to proceed!" $tecreset
else
	echo "Dmidecode application is not installed on device, part of the script will not work without it!"
	echo "Would you like to install 'Dmidecode'?(y/n): "
	read user_input
	if [ ${user_input} = y ]
	then
		echo -e "$dmiinstall"
	else
		echo
	fi
fi

# Check for ufw executable
ufwinstall=$(zypper install ufw)
file="/usr/sbin/ufw"
if [ -f "$file" ]
then
	echo -e '\033[0;31m'"UFW application already installed, Ok to proceed!" $tecreset
	echo
else
	echo "UFW application is not installed on device, part of the script will not work without it!"
	echo "Would you like to install 'UFW'?(y/n): "
	read user_input
	if [ ${user_input} = y ]
	then
		echo -e "$ufwinstall"
	else
		echo
	fi
fi

# Define Variable tecreset
tecreset=$(tput sgr0)													#tput sgr0 means turn off standout/colour (colour green to white) 

externalip=$(curl -s ipecho.net/plain;echo)								#External IP -explained further down script

# Check OS Release Version and Name
cat /etc/os-release | grep 'NAME\|VERSION' | grep -v 'VERSION_ID' | grep -v 'PRETTY_NAME' > /tmp/osrelease			#pulls info from cat /etc/os-release | info pulled by grep on condition of meeting criteria in '' | grep -v means invert the sense of matching, to select non-matching lines
echo -n -e '\033[0;31m'"OS Name:" $tecreset  && cat /tmp/osrelease | grep -v "VERSION" | cut -f2 -d\"				#grep -n means do not output the trailing newline | grep -e means enable interpretation of backslash escapes

#echo

echo -n -e '\033[0;31m'"OS Version:" $tecreset && cat /tmp/osrelease | grep -v "NAME" | cut -f2 -d\"				#same as above however grep uses matching to "NAME" in /tmp/osrelease file

#echo

# Check Architecture
architecture=$(uname -m)												#uname is system information with argument -m which is machine hardware name
echo -e '\033[0;31m'"Architecture:" $tecreset $architecture				#arch.

#echo

# Check Kernel Release
kernelrelease=$(uname -r)												#uname is system information with argument -r which is  --kernel-release
echo -e '\033[0;31m'"Kernel Release:" $tecreset $kernelrelease			#kernel

#echo

# Shell Type
shelltype=$(finger -l | sed '2!d' | awk '{print $4}')					#finger command can output information such as login shell | sed command keeps only the second line of file | awk prints only 4th word
echo -e '\033[0;31m'"Shell Type:" $tecreset $shelltype					#shell type

#echo

# Check hostname
echo -e '\033[0;31m'"Hostname:" $tecreset $HOSTNAME						#$HOSTNAME is a variable (of comp hostname) provided by shell	

#echo

# Check Packages Installed
packages=$(zypper -se | wc --lines)                 					#debian package manager with --list argument outputing list of all packages installed | word count function counting number of lines            
echo -e '\033[0;31m'"Packages Installed:" $tecreset "$packages"			#Number of packages installed on system

#echo

# All users
usersall=$(lslogins -u | sed '1d' | awk '{print $2}')					#lslogins -display info of known users in system | sed removes first line | awk prints 2nd word of remaining lines
echo -e '\033[0;31m'"All Users:" $tecreset $usersall 					#list all users
#echo $tecreset"$usersall"

#echo

# Check Logged In Users
who>/tmp/who															#who>/tmp/who transfers who command result (shows who is logged on) to /tmp/who file
echo -e '\033[0;31m'"Logged In Users:" $tecreset && cat /tmp/who		#combines colour to default variable with displaying contents of /tmp/who file

#echo

# ID of 1st Logged in User
iduser1=$(users | awk '{print $1}')										#user names of users currently logged in | prints first word
echo -e '\033[0;31m'"ID of 1st Logged in User:" $tecreset 				#Logged in user
echo $tecreset | id "$iduser1"

#echo

# Location of user
#whois=$(whois)
#externalip1=$(cat /tmp/externalipoutput)	
#externalip=$(curl -s ipecho.net/plain;echo > /tmp/externalipoutput)														
#echo -e '\033[0;31m'"Location of User:" $tecreset $externalip  
#echo 'whois' $externalip1 | sed '10!d' | awk '{print $2}' 				#Piping whois command external IP variable
#echo -e '\033[0;31m'"Location of User:" whois $externalip
#echo -e "$whois $externalip"											#Location of user | whois command - client for the whois directory service

#echo

# Day, date, time, year
#ddty=$(TZ="Africa/Casablanca" date)								    #
#echo -e '\033[0;31m'"Day, date, time, year:" $tecreset $ddty

#echo

# Check System Uptime
tecuptime=$(uptime | awk '{print $3}' | cut -f1 -d,)										#filters only uptime in hours | awk prints 3rd | cut command (-d,) removes comma
echo -e '\033[0;31m'"System Uptime Days/(HH:MM):" $tecreset $tecuptime						#Uptime of device

#echo

# Check Tasks results from top command
tasktop=$(top -n 1 -b | sed '2!d' | awk '{print $2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12}')		#top command with batch arg | keep only 2nd line | Print all but first word
echo -e '\033[0;31m'"Tasks:" $tecreset $tasktop												#task results

#echo

# Check Load Average
loadaverage=$(top -n 1 -b | grep "load average:" | awk '{print $10 $11 $12}')		#grep filters to only anything on line of load average: | awk only prints 10th 11th and 12th word | top - display Linux processes - argument 1 iteration (-n 1) + batch mode
echo -e '\033[0;31m'"Load Average:" $tecreset $loadaverage							#load averages

# Number of executable commands
#cd /root/Desktop/SystemNetworkMonitor
excount=$(./pathcommands.sh)														#
echo -e '\033[0;31m'"Number of executable commands:" $tecreset"$excount"     		#Number of executable commands

# Log Directry Size
logsize=$(du -h -s /var/log | awk '{print $1}')										#du -deals with file space usage | arg human readable | arg summary totals (/var/log) | print only first word
echo -e '\033[0;31m'"Log Directory Size (/var/log/):" $tecreset"$logsize"     		#Size of log directory

#echo

# Number of Items In Log
itemslog=$(ls -l /var/log | wc -l)													#ls -with long listing argument (file per line in /var/log) | word count of lines = Number of Items in Log
echo -e '\033[0;31m'"Number of Items in Log:" $tecreset"$itemslog"     				#Number of items in log

#echo

# Motherboard Manufacturer
mboardman=$(dmidecode -s baseboard-manufacturer)									#dmidecode -used to output device hardware with motherboard manufacturer argument
echo -e '\033[0;31m'"Motherboard Manufacturer:" $tecreset "$mboardman"     			#Motherboard Manufacturer

#echo

# CPU Model Name 
cpumodel=$(lscpu | grep "Model name:" | awk '{print $3, $4, $5, $6, $7, $8, $9}')	#CPU architecture info | grep keeping CPU Model: line | awk keeping stated words 
echo -e '\033[0;31m'"CPU Model:" $tecreset "$cpumodel"     							#CPU Model

#echo

# CPU Family
cpufamily=$(dmidecode -s processor-family)											#dmidecode -used to output device hardware with processor family argument 
echo -e '\033[0;31m'"CPU Family:" $tecreset "$cpufamily"     						#CPU Family

#echo

# CPU Current Clock Speed
cpufreq=$(dmidecode -s processor-frequency)											#dmidecode -used to output device hardware with processor frequency argument
echo -e '\033[0;31m'"CPU Current Clock Speed:" $tecreset "$cpufreq"     			#CPU Current Clcok Speed

#echo

# CPU Max Clock Speed
cpumcspeed=$(dmidecode -t 4 | grep "Max Speed:" | awk '{print $3 $4}')				#dmidecode -used to output device hardware with type 4 entry result | filtered to Max Speed; line | print given words on line
echo -e '\033[0;31m'"CPU Max Clock Speed:" $tecreset "$cpumcspeed"     				#CPU Max Clock Speed

#echo

# Maximum RAM Slotage
ramslot=$(dmidecode -t 16 | sed '10!d' | awk '{print $3,$4}')						#dmidecode -used to output device hardware with type 16 entry result | keeps line 10 | printing stated words on line
echo -e '\033[0;31m'"Maximium RAM Slotage:" $tecreset "$ramslot"     				#Maximum RAM Slotage

#echo

# Network Interface Cards
nic=$(cat /proc/net/dev | sed '1 d' | awk '{print $1}')								#cat -output to terminal (/proc/net/dev) | sed removes first line | awk prints only first word of remaining lines
echo -e '\033[0;31m'"Available Network Interfaces:" $tecreset $nic					#all network interfaces seperated by :

# CPU Threads & Cores
cputhreadcore=$(lscpu | egrep '^Thread|^Core|^Socket|^CPU\(')						#egrep used to print lines matching given patterns
echo -e '\033[0;31m'"CPU Thread & Core:" 
echo $tecreset"$cputhreadcore"     													#CPU Threads & Cores

echo

# Check RAM and SWAP Usages
free -h | grep -v + > /tmp/ramcache										#free and used sys memory (human readable arg.) | grep arg. select non-matching lines | output into /tmp/ramcache 
echo -e '\033[0;31m'"Ram Usage:" $tecreset
cat /tmp/ramcache | grep -v "Swap"										#grep -v "Swap" filters only Swap result from free- h command
echo -e '\033[0;31m'"Swap Usage:" $tecreset
cat /tmp/ramcache | grep -v "Mem"										#grep -v "Mem" filters only Mem result from free- h command

echo 

# contents of comp directory
#cd /root/Desktop/SystemNetworkMonitor
compdir=$(./contents.sh /)												#contents of comp directory script in / directory
echo -e '\033[0;31m'"Computer directory contents:" 
echo $tecreset"$compdir"     											

echo

# Top Processes in order of CPU Usage
pscpu=$(ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head)				#process snapshot (arg= every process with a user-defined format:) | head -output first part of file only
echo -e '\033[0;31m'"Top Processes in Order of CPU Usage:" 
echo $tecreset"$pscpu"     												#Top Processes in order of CPU Usage

echo

# Top Processes in order of RAM Usage
psram=$(ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head)				#process snapshot (arg= every process with a user-defined format:) | head -output first part of file only
echo -e '\033[0;31m'"Top Processes in Order of RAM Usage:" 
echo $tecreset"$psram"     												#Top Processes in order of RAM Usage

#echo

# Iostat
#iostat=$(iostat | awk '{print $3,$4,$5,$6,$7,$8,$9,$10,$11,$12}')
#echo -e '\033[0;31m'"Iostat:" 
#echo $tecreset"$iostat"     											#Iostat | commented out due to format | could still be used for certain stats

echo

# Check Disk Usages
df -h| grep 'Filesystem\|/dev/sda*' > /tmp/diskusage					#df -disk space usage | filter only /dev/sda lines | output to /tmp/diskusage file
echo -e '\033[0;31m'"Disk Usage:" $tecreset 
cat /tmp/diskusage														#display given file contents

echo

# Partition Report
partrep=$(df -H)														#df -disk space usage with arg. print sizes in powers of 1000 
echo -e '\033[0;31m'"Partition Report:" 
echo $tecreset"$partrep"     											#Partition Report

echo

# Last 10 lines on journalctl
journal=$(journalctl | tail -n 10)										#Query the systemd journal | output only last 10 (most recent) lines
echo -e '\033[0;31m'"Recent (last 10 lines) Journalctl:" 
echo $tecreset"$journal"     											#Recent (last 10 lines) Journalctl

echo

# Iptables List Rules
iptablesrules=$(iptables --list-rules)									#iptables -administration tool for IPv4/IPv6 packet filtering  | arg. list all rules
echo -e '\033[0;31m'"Iptables List Rules:" 
echo $tecreset"$iptablesrules"     										#Iptables List Rules

echo

# UFW Status
ufwstatus=$(ufw status verbose)											#ufw -program for managing a netfilter firewall | arg. in detail
echo -e '\033[0;31m'"UFW Status:" 
echo $tecreset"$ufwstatus"     											#UFW Status

echo

# Devices Connected by USB
usbdev=$(lsusb)															#list devices connected by usb
echo -e '\033[0;31m'"Devices Connected by USB:" 
echo $tecreset"$usbdev"     											#Connected USB devices

# PCI Connected Devices
#pcidev=$(lspci)
#echo -e '\033[0;31m'"P:" $tecreset "$pcidev"     						#PCI connected devices (commented out -too much detail for script -just preference) 

echo

# Sesors Information
#sensors=$(sensors)														#sensors -print sensors information
#echo -e '\033[0;31m'"Sensors:" 
#echo $tecreset"$sensors"     											#Sensors information

#echo

# Audio Controller
lspciaudio=$(lspci -v | grep -A7 -i "audio" | sed '3,10d' | sed '5,11d')		#lspci - list all PCI devices | print only lines with audio | removing lines 3-10 | then of remaing remove lines 5-11
echo -e '\033[0;31m'"Audio Controllers:" 
echo $tecreset"$lspciaudio"     												#Audio Controller Hardware Info | sed command removes lines in between given numbers

echo

# Graphics Card Info
lspcigraph=$(lspci -nnk | grep VGA -A1)											#lspci - list all PCI devices arg. Show PCI vendor and device codes as both numbers and names arg. show kernel drivers | grep filters vga results										
echo -e '\033[0;31m'"Graphics Card:" 
echo $tecreset"$lspcigraph"     												#Graphics Card Hardware Info 

echo

# Check Network Adapter Details
nadapter=$(lspci -nnk | grep net -A2)											#lspci - list all PCI devices arg. Show PCI vendor and device codes as both numbers and names arg. show kernel drivers | grep net results
echo -e '\033[0;31m'"Network Adapter Details:" 
echo $tecreset"$nadapter"

# Unset Variables
unset tecreset os architecture kernelrelease loadaverage		#removes all previously set variables with unset command

# Remove Temporary Files
rm /tmp/osrelease /tmp/who /tmp/ramcache 				#removes all newley created temporary files

}
fi																								#ends if statement
shift $(($OPTIND -1))																			#needed to end getopts command | $(($OPTIND -1)) removes all the options that have been parsed by getopts from the parameters list

