#! /bin/bash

# Define Variable tecreset
tecreset=$(tput sgr0)

echo
echo -e '\033[0;31m'"Please wait 60 seconds whilst the averages are calculated..." $tecreset
echo

end=$((SECONDS+60))

while [ $SECONDS -lt $end ]; do

#OUTPUT="$(ps -A -o pcpu | tail -n+2 | paste -sd+ | bc >> /tmp/cpuusageaverage)"
OUTPUT="$(top -b -n1 | grep "Cpu(s)" | awk '{print $2 + $4}' >> /tmp/cpuusageaverage)"

${OUTPUT}

done	

echo
echo -e '\033[0;31m'"CPU utilisation (%) over 60 seconds:" $tecreset
echo

cat /tmp/cpuusageaverage \
| perl -M'List::Util qw(sum max min)' -MPOSIX -0777 -a -ne 'printf "%-7s : %d\n"x4, "Min", min(@F), "Max", max(@F), "Average", sum(@F)/@F,  "Median", sum( (sort {$a<=>$b} @F)[ int( $#F/2 ), ceil( $#F/2 ) ] )/2;'

echo

rm /tmp/cpuusageaverage
